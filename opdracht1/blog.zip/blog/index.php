
<?php require_once 'header.php';?>

  <body>

<?php
$current = 'index.php';
require_once 'navigatie.php'; ?>

    <div class="container">

      <div class="starter-template">
        <h1>Home</h1>
        <p class="lead">Homepagina.</p>
      </div>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php require_once 'footer.php';?>
